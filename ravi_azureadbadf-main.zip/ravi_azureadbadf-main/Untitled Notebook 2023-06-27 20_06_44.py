# Databricks notebook source
# MAGIC %sql
# MAGIC select * from emp_delta
