# Databricks notebook source
# MAGIC %sql
# MAGIC show databases;

# COMMAND ----------

# MAGIC %sql
# MAGIC use gold_ticket_db;
# MAGIC show tables;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from listings_fact

# COMMAND ----------


