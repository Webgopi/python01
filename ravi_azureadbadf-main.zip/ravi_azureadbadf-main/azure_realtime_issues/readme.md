azure realtime issues
